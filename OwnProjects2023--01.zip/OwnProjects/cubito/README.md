# CG-3-Mosqueteros

## Demo ![Youtube icon](doc/youtube_icon.png)
Click on the following [**link**](https://youtu.be/LZ0UQ9Ynly0) to see the demo on Youtube.
